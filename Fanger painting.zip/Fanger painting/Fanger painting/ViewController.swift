//
//  ViewController.swift
//  Fanger painting
//
//  Created by Saad altwaim on 10/23/22.
//
// The source for this Tutorial This Link
// (https://www.raywenderlich.com/1934-how-to-make-a-simple-drawing-app-with-uikit-and-swift

import UIKit
//import CoreGraphics

class ViewController: UIViewController
{
    @IBOutlet weak var tempImageView2: UIImageView!
    @IBOutlet weak var mainImageView: UIImageView!
    // CGFloat is a regular float on 32-bit systems and a double on 64-bit systems
    
    var lastPoint  = CGPoint.zero    // Page 23 Note3
    var blue       = UIColor.blue
    var brushWidth : CGFloat = 10.0 //  store the brush stroke width Page 24 Note 3
    var opacity    : CGFloat = 1.0  //  store the brush opacity Page 24 Note 4
    var swiped     = false          //  identifies if the brush stroke is continuous Page 24 Note 1
    
    let paintStrokeUndoManager = PaintStrokeUndoManager.shared
    let activeStrokes = PaintStrokeSaver.shared.restore(name: "active_strokes")
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
  // touchesBegan is called when the user puts a finger down on the screen. This is the start of a drawing event
      
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) // Page 24 Note 2
    {
        swiped = false //so you first reset swiped to false since the touch hasn’t moved yet
        
        if let touch = touches.first
        {
            lastPoint = touch.location(in: self.view) // Page 24 Note 5
        }
    }
    
    func drawLineForm(fromPoint : CGPoint , toPoint : CGPoint)
    {
        // Page 24 Note 6
        UIGraphicsBeginImageContext(view.frame.size) // A
        let context = UIGraphicsGetCurrentContext() // B
        tempImageView2.image?.draw(in:CGRect(x: 0, y: 0, width: view.frame.size.width, height: view.frame.size.height)) // C
        
//        let path = CGMutablePath() // Page 25 Note 3
//        path.move(to: CGPoint(x: fromPoint.x, y: fromPoint.y)) //old CGContextMoveToPoint - Page 25 Note 1
//        path.addLine(to: CGPoint(x: toPoint.x, y: toPoint.y)) // Old CGContextAddLineToPoint - Page 25 Note 2
        
        context!.move(to: CGPoint(x: fromPoint.x, y: fromPoint.y)) //old CGContextMoveToPoint - Page 25 Note 1
        context!.addLine(to: CGPoint(x: toPoint.x, y: toPoint.y)) // Old CGContextAddLineToPoint - Page 25 Note 2
        
        // Page 25 Note 4
        context?.setLineCap(.round)  // A
        context?.setLineWidth(brushWidth) // B
        context?.setStrokeColor(blue.cgColor) // C
        context?.setBlendMode(.normal) // D
        
        context?.strokePath() // This is where the magic happens, and where you actually draw the path
        
        // Page 25 Note 5
        tempImageView2.image = UIGraphicsGetImageFromCurrentImageContext() // A
        tempImageView2.alpha = opacity // B

        UIGraphicsEndImageContext() // C
        
        let paintStroke: PaintStroke = PaintStroke(strokeWidth: brushWidth,
                                                         color: blue,
                                                          path: StrokePath(points: [fromPoint , toPoint]))
//        let paintStroke2: PaintStroke = PaintStroke(strokeWidth: brushWidth, color: blue, path: StrokePath(points: [toPoint]))
        
        paintStrokeUndoManager.add(stroke: paintStroke)
//        paintStrokeUndoManager.add(stroke: paintStroke2)
        
//        for stroke in activeStrokes
//        {
//            paintStrokeUndoManager.add(stroke: stroke)
//        }
        
        PaintStrokeSaver.shared.save(paintStrokes: paintStrokeUndoManager.activeStrokes, name: "active_strokes")
    }
    
    // Page 26 Note 1
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) // A
    {
        swiped = true
        //you set swiped to true so you can keep track of whether there is a current swipe in progress.
        // Since this is touchesMoved, the answer is yes, there is a swipe in progress!
        if let touch = touches.first // B
        {
            let currentPoint = touch.location(in: view) // C
            drawLineForm(fromPoint: lastPoint, toPoint: currentPoint) // D
            
            lastPoint = currentPoint // you update the lastPoint so the next touch event will continue where you just left off.
        }
    }
    // Page 26 Note 2
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) // B
    {
        if (!swiped) // A
        {
            drawLineForm(fromPoint: lastPoint, toPoint: lastPoint)
        }
        
        // Page 27 Note 1
        UIGraphicsBeginImageContext(mainImageView.frame.size)
        let rect = CGRect(x: 0, y: 0, width: view.frame.size.width, height: view.frame.size.height)
        mainImageView.draw(rect)
        mainImageView.alpha = 1.0
        
        tempImageView2.draw(rect)
        tempImageView2.alpha = opacity

        mainImageView.image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()

        tempImageView2.image = nil

    }
    
    @IBAction func Redo(_ sender: Any)
    {
        paintStrokeUndoManager.redo()
        
        for stroke in activeStrokes
        {
            paintStrokeUndoManager.add(stroke: stroke)
        }

        UIGraphicsBeginImageContext(tempImageView2.frame.size)
        
        let rect = CGRect(x: 0,
                          y: 0,
                          width: view.frame.size.width,
                          height: view.frame.size.height)
        
        mainImageView.draw(rect)
        mainImageView.alpha = 1.0
        mainImageView.image = nil
        
        tempImageView2.draw(rect)
        tempImageView2.alpha = opacity
        tempImageView2.image = UIGraphicsGetImageFromCurrentImageContext()
                
        UIGraphicsEndImageContext()
        
    }
    
    @IBAction func Undo(_ sender: Any)
    {

        let rect = CGRect(x: 0,
                          y: 0,
                          width: view.frame.size.width,
                          height: view.frame.size.height)

        tempImageView2.draw(rect)
        tempImageView2.alpha = 1.0
        tempImageView2.image = nil
        
        UIGraphicsBeginImageContext(mainImageView.frame.size)
        
        mainImageView.draw(rect)
        mainImageView.alpha = opacity
        mainImageView.image = UIGraphicsGetImageFromCurrentImageContext()
        
//        let activeStrokes = PaintStrokeSaver.shared.restore(name: "active_strokes")
        for stroke in activeStrokes
        {
            paintStrokeUndoManager.add(stroke: stroke)
        }
        paintStrokeUndoManager.undo()

        UIGraphicsEndImageContext()
        
    }
    
    @IBAction func Reset(_ sender: Any)
    {
        mainImageView.image = nil
    }
}

// what is CGFloat
//(https://stackoverflow.com/questions/1264924/whats-the-difference-between-using-cgfloat-and-float )

//What is a graphics context?
//(https://stackoverflow.com/questions/22740543/in-ios-core-graphics-what-is-a-graphicscontext)

// drawLineForm paramter function
//(https://stackoverflow.com/questions/58597806/drawing-perfect-rounding-lines-swift)

//setBlendMode(.normal)
//(https://stackoverflow.com/questions/23497703/union-uibezierpaths-rather-than-apend-path/41179791#41179791)
