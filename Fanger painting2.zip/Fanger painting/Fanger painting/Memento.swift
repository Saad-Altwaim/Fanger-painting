import Foundation
import UIKit

struct PaintStroke {
    let strokeWidth: CGFloat
    let color: UIColor
    let path: StrokePath
}

/// Encapsulates points along the stroke path.
struct StrokePath {
    let points: [CGPoint]
}


/// The serialized state of the originator PaintStroke (i.e. this is the "memento").
// Page 20 Note 2
typealias PaintStrokeMemento = [String: Any]

/// A protocol for objects that can be converted to a memento. This should be implemented by the originator
// Page 20 Note 3
protocol MementoStorable {
    var memento: PaintStrokeMemento { get }
    init?(memento: PaintStrokeMemento)
}

/// Extension of `PaintStroke` that conforms to `MementoStorable`. The memento created from a `PaintStroke` object is simply a dictionary, conversely, a `PaintStroke` object can be created from a dictionary.
// Page 20 Note 4
extension PaintStroke: MementoStorable {
    private struct MementoKeys {
        static let strokeWidth = "stroke_width"
        static let color = "color"
        static let path = "path"
    }

    // Page 20 Note 5
    var memento: PaintStrokeMemento {
        return [
                          //[String: Any]
            MementoKeys.strokeWidth: strokeWidth,
            MementoKeys.color:       color,
            MementoKeys.path:        path
        ]
    }

    // Page 21 Note 1
    // (https://stackoverflow.com/questions/28987295/swift-cast-dictionary-value-as-type)
    init?(memento: PaintStrokeMemento)
    {
        guard let strokeWidth = memento[MementoKeys.strokeWidth] as? CGFloat,  //This attempts to cast the value as a CGFloat
              let color = memento[MementoKeys.color] as? UIColor,
              let path  = memento[MementoKeys.path]  as? StrokePath else { return nil }
        
        // Page 21 Note 6 - A
        self.strokeWidth = strokeWidth
        self.color = color
        self.path = path
    }
}

//Caretaker Class And use singleton
class PaintStrokeUndoManager { // Page 22 Note 1
    static let shared = PaintStrokeUndoManager()
// The static field that controls the access to the singleton instance

//(https://stackoverflow.com/questions/37264824/how-does-public-privateset-access-modifiers-work)
    private(set) var activeStrokes = [PaintStroke]() // Page 21 Note 2
    private var undidStrokes = [PaintStroke]()
    
// (https://medium.com/@abhishek1nacc/singleton-in-swift-5d44c5064630)
// (https://refactoring.guru/design-patterns/singleton/swift/example)
    private init() { } // Page 21 Note 3
    
    func add(stroke: PaintStroke) { // Page 22 Note 2
        activeStrokes.append(stroke)
    }

    func redo() { // Page 22 Note 3
        guard !undidStrokes.isEmpty else { return }
        let mostRecentUndidStroke = undidStrokes.removeLast()
        add(stroke: mostRecentUndidStroke)
//        print("the mostRecentUndidStroke : ",mostRecentUndidStroke)
    }

    func undo() { // Page 22 Note 4
        guard !activeStrokes.isEmpty else { return }
        let mostRecentStroke = activeStrokes.removeLast()
        undidStrokes.append(mostRecentStroke)
//        print("undo")
    }
}

// singleton
class PaintStrokeSaver {
    static let shared = PaintStrokeSaver()

    func save(paintStrokes: [PaintStroke], name: String) { // Page 22 Note 5
        let defaults = UserDefaults.standard
//        defaults.synchronize() // to make the user defaults get written on disk immediately.
        defaults.set(paintStrokes,forKey: name)
    }

    
    func restore(name: String) -> [PaintStroke] {
        let defaults = UserDefaults.standard
        // Page 23 Note 1
        guard let mementos = defaults.object(forKey: name) as? [PaintStrokeMemento]
        else
        {
            return []
        }

        var paintStrokes = [PaintStroke]()
        for memento in mementos {
            if let paintStroke = PaintStroke(memento: memento) { // Page 23 Note 2
                paintStrokes.append(paintStroke)
            }
        }
        return paintStrokes
    }
}




//    from here we run hte Code
//    let paintStroke1: PaintStroke = PaintStroke(strokeWidth: 1, color: .black, path: StrokePath(points: []))
//    let paintStroke2: PaintStroke = PaintStroke(strokeWidth: 1, color: .blue, path: StrokePath(points: []))
//    let paintStrokeUndoManager = PaintStrokeUndoManager.shared
//    paintStrokeUndoManager.add(stroke: paintStroke1)
//    paintStrokeUndoManager.add(stroke: paintStroke2)
//
//    // Undo/redo
//    paintStrokeUndoManager.undo()
//    paintStrokeUndoManager.redo()
//
//    // The list of all active strokes which the view can render
//    paintStrokeUndoManager.activeStrokes
//
//    PaintStrokeSaver.shared.save(paintStrokes: paintStrokeUndoManager.activeStrokes, name: "active_strokes")


//    Restore
//    let activeStrokes = PaintStrokeSaver.shared.restore(name: "active_strokes")
//    for stroke in activeStrokes {
//    paintStrokeUndoManager.add(stroke: stroke)
//}

